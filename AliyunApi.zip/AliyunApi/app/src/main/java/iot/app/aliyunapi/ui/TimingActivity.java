package iot.app.aliyunapi.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import iot.app.aliyunapi.MainActivity;
import iot.app.aliyunapi.R;
import iot.app.aliyunapi.model.impl.ApiImpl;

public class TimingActivity extends AppCompatActivity {

    private ImageButton but_t;
    private TextView text_t;
    private EditText editText_t;
    private int p=0;
    private int t_max=88887;
    private ApiImpl apl=new ApiImpl();
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timing);
        but_t= (ImageButton) findViewById(R.id.iButton);
        text_t=(TextView) findViewById(R.id.textView_timing);
        editText_t=(EditText) findViewById(R.id.edit_time);
        handler=new Handler();
        Runnable runnable=new Runnable() {
            @Override
            public void run() {
                p--;
                if(p>=0){
                    text_t.setText("定时模式："+p+"s");
                    handler.postDelayed(this,1000);
                }
                else {
                    p=0;
                }
            }
        };
        but_t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handler.removeCallbacks(runnable);
                editText_t.clearFocus();//取消聚焦
                String t =editText_t.getText().toString();
                if (!t.equals("")){
                    p=Integer.parseInt(t);
                    if (t_max>p&&p>0){
                        apl.timing(p);//发送
                        if(apl.isV()){
                            text_t.setText("定时模式：已开启");
                            handler.post(runnable);
                        }else {
                            Toast.makeText(TimingActivity.this,"定时模式启动失败，请检查网络连接",Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(TimingActivity.this,"时间需在1~80000",Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(TimingActivity.this,"时间不能为空",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
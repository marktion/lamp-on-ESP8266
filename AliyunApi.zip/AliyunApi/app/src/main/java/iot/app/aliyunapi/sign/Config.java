package iot.app.aliyunapi.sign;
/*
 * Copyright © 2018 Alibaba. All rights reserved.
 */

/**
 * 服务端API签名配置文件
 *
 * @author: ali
 * @version: 0.1 2018-08-08 08:23:54
 */
public class Config {

    // AccessKey信息
    public static String accessKey = "阿里云openapi";
    public static String accessKeySecret = "阿里云openapi";

    public final static String CHARSET_UTF8 = "utf8";
}

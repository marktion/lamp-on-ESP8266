package iot.app.aliyunapi.model.device;

public class Device {
    private String Status;
    private String IotId;
    private String GmtCreate;
    private String ActiveTime;
    private String GmtModified;
    private String ProductKey;
    private String DeviceName;


    public String getStatus() {
        return Status;
    }
}

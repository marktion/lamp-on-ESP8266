package iot.app.aliyunapi.model.impl;

import android.util.Log;
import android.widget.TextView;


import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import iot.app.aliyunapi.MainActivity;
import iot.app.aliyunapi.api.Api;
import iot.app.aliyunapi.model.device.Device;
import iot.app.aliyunapi.model.message.Property;
import iot.app.aliyunapi.model.message.ResMsg;
import iot.app.aliyunapi.sign.Config;
import iot.app.aliyunapi.sign.SignatureUtils;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ApiImpl {
    Map<String, String> map = new HashMap<String, String>();//存储提交内容
    String msg;//错误提示
    boolean v=true;//成功标记
    String status="UNACTIVE";

    public String getStatus() {
        return status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isV() {
        return v;
    }

    public void setV(boolean v) {
        this.v = v;
    }


    public String signature(Map<String, String> map) throws Exception {

        java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        df.setTimeZone(new java.util.SimpleTimeZone(0, "GMT"));// 这里一定要设置GMT时区
        Date date = new java.util.Date();
        String nonce = java.util.UUID.randomUUID().toString();//生成随机码

        // 请求参数
        map.put("DeviceName", "设备名称");
        map.put("IotInstanceId","实例ID");
        map.put("ProductKey", "密钥");
        // 公共参数
        map.put("Format", "JSON");//格式
        map.put("Version", "2018-01-20");//版本
        map.put("AccessKeyId", Config.accessKey);//密钥ID
        map.put("SignatureMethod", "HMAC-SHA1");//签名算法
        map.put("Timestamp", df.format(date));//时间戳
        map.put("SignatureVersion", "1.0");//签名版本
        map.put("SignatureNonce", nonce);
        map.put("RegionId", "cn-shanghai");//域名地址

        String signature = SignatureUtils.generate("POST", map, Config.accessKeySecret);//生成API签名
        System.out.println("最终signature: " + signature);
        map.put("Signature", signature);

        return signature;//返回生成的签名
    }
    public void onLigh(){
        map.clear();
        map.put("Action", "SetDeviceProperty");
        map.put("Items", "{\"Status\":1,\"switch\":0}");
        try {
            signature(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Api api=Api.retrofit.create(Api.class);
        Call<ResMsg<Property>> call=api.openApi(map);
        call.enqueue(new Callback<ResMsg<Property>>() {
            @Override
            public void onResponse(Call<ResMsg<Property>> call, Response<ResMsg<Property>> response) {
                if (response.body().getSuccess()==null)
                { v=false;
                }else { v = response.body().getSuccess();}
            }

            @Override
            public void onFailure(Call<ResMsg<Property>> call, Throwable t) {
                msg=t.getMessage();
                Log.i("错误",msg);
                v=false;
            }
        });
    }
    public void offLigh(){
        map.clear();
        // 请求参数
        map.put("Action", "SetDeviceProperty");
        map.put("Items", "{\"Status\":0,\"switch\":0}");
        try {
            signature(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Api api=Api.retrofit.create(Api.class);
        Call<ResMsg<Property>> call=api.openApi(map);
        call.enqueue(new Callback<ResMsg<Property>>() {
            @Override
            public void onResponse(Call<ResMsg<Property>> call, Response<ResMsg<Property>> response) {
                if (response.body().getSuccess()==null)
                { v=false;
                }else { v = response.body().getSuccess();}
            }

            @Override
            public void onFailure(Call<ResMsg<Property>> call, Throwable t) {
                msg=t.getMessage();
                Log.i("错误",msg);
                v=false;
            }
        });
    }
/*调用该接口通过类SQL语句快速搜索满足指定条件的设备。
 */
    public void QueryDeviceBySQL(){
        map.clear();
        // 请求参数
        map.put("Action", "QueryDeviceBySQL");
        map.put("SQL","SELECT * FROM device where name = \"tttt1\" limit 1");
        try {
            signature(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Api api=Api.retrofit.create(Api.class);
        Call<ResMsg<List<Device>>> call=api.QueryDevice(map);
        call.enqueue(new Callback<ResMsg<List<Device>>>() {
            @Override
            public void onResponse(Call<ResMsg<List<Device>>> call, Response<ResMsg<List<Device>>> response) {
                ResMsg<List<Device>> resMsg=response.body();
                List<Device> devices=resMsg.getData();
                status=devices.get(0).getStatus();
            }

            @Override
            public void onFailure(Call<ResMsg<List<Device>>> call, Throwable t) {
                msg=t.getMessage();
                Log.i("错误",msg);
            }
        });
    }
    /*
    定时模式
     */
    public void timing(int t){
        map.clear();
        // 请求参数
        map.put("Action", "SetDeviceProperty");
        map.put("Items", "{\"S\":"+t+",\"switch\":1}");
        try {
            signature(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Api api=Api.retrofit.create(Api.class);
        Call<ResMsg<Property>> call=api.openApi(map);
        call.enqueue(new Callback<ResMsg<Property>>() {
            @Override
            public void onResponse(Call<ResMsg<Property>> call, Response<ResMsg<Property>> response) {
                if (response.body().getSuccess()==null)
                { v=false;
                }else {
                    v = true;}
            }

            @Override
            public void onFailure(Call<ResMsg<Property>> call, Throwable t) {
                msg=t.getMessage();
                Log.i("错误",msg);
                v=false;
            }
        });
    }
    /*
   夜间模式
    */
    public void nightMode(int n){
        map.clear();
        // 请求参数
        map.put("Action", "SetDeviceProperty");
        map.put("Items", "{\"switch\":"+n+"}");
        try {
            signature(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Api api=Api.retrofit.create(Api.class);
        Call<ResMsg<Property>> call=api.openApi(map);
        call.enqueue(new Callback<ResMsg<Property>>() {
            @Override
            public void onResponse(Call<ResMsg<Property>> call, Response<ResMsg<Property>> response) {
                if (response.body().getSuccess()==null)
                { v=false;
                }else { v = response.body().getSuccess();}
            }
            @Override
            public void onFailure(Call<ResMsg<Property>> call, Throwable t) {
                msg=t.getMessage();
                Log.i("错误",msg);
                v=false;
            }
        });
    }
}

package iot.app.aliyunapi.sign;

public interface Invoke {
}

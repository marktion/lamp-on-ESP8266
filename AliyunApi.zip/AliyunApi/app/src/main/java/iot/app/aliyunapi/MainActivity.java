package iot.app.aliyunapi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import iot.app.aliyunapi.model.impl.ApiImpl;

import iot.app.aliyunapi.ui.TimingActivity;


public class MainActivity extends AppCompatActivity {
    private ApiImpl apl=new ApiImpl();
    private int f=0;//夜间模式背景标记
    private Handler handler1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView textView=findViewById(R.id.textView);
        ConstraintLayout constraintLayout=findViewById(R.id.container);
        Button on=findViewById(R.id.bulbOnBtn);//开
        Button off=findViewById(R.id.bulbOffBtn);//关
        Button nbuton=findViewById(R.id.but_n);
        Button webbut=findViewById(R.id.webbut);
        Button but=findViewById(R.id.but);//定时
        ImageView lamp= findViewById(R.id.imageView);
        lamp.setImageResource(R.drawable.lamp1);

        View.OnClickListener listener=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()){
                    case R.id.bulbOnBtn:
                        apl.onLigh();
                        constraintLayout.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
                        if(apl.isV()){
                            lamp.setImageResource(R.drawable.lamp1);
                            Toast.makeText(MainActivity.this,"已开灯",Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(MainActivity.this,"开灯失败，请检查网络连接",Toast.LENGTH_SHORT).show();
                        }
                        break;
                    case R.id.bulbOffBtn:
                        apl.offLigh();
                        constraintLayout.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
                        if(apl.isV()){
                            lamp.setImageResource(R.drawable.lamp0);
                            Toast.makeText(MainActivity.this,"已关灯",Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(MainActivity.this,"关灯失败，请检查网络连接",Toast.LENGTH_SHORT).show();
                        }
                        break;
                    case R.id.but:
                        constraintLayout.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
                        f=0;
                        Intent intent_t=new Intent(MainActivity.this, TimingActivity.class);
                        startActivity(intent_t);
                        break;
                    case R.id.webbut:
                        Uri uri= Uri.parse("http://192.168.4.1/");
                        Intent intent_w=new Intent(Intent.ACTION_VIEW,uri);
                        startActivity(intent_w);
                        break;
                    case R.id.but_n:
                        if(apl.isV()){
                            if (f==0){
                                f=1;
                                apl.nightMode(2);
                                constraintLayout.setBackgroundColor(Color.parseColor("#FF000000"));//黑
                            }else {
                                f=0;
                                apl.nightMode(0);
                                lamp.setImageResource(R.drawable.lamp0);
                                constraintLayout.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
                            }
                        }else {
                            if (f==0){//没有网络则不改变
                                constraintLayout.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
                            }else {
                                constraintLayout.setBackgroundColor(Color.parseColor("#FF000000"));//黑
                            }
                            Toast.makeText(MainActivity.this,"请检查网络连接",Toast.LENGTH_SHORT).show();
                        }
                        break;
                    default:
                        break;
                }
            }
        };
        on.setOnClickListener(listener);
        off.setOnClickListener(listener);
        nbuton.setOnClickListener(listener);
        webbut.setOnClickListener(listener);
        but.setOnClickListener(listener);
        handler1=new Handler();
        Runnable runnable=new Runnable() {
            @Override
            public void run() {
                apl.QueryDeviceBySQL();
                handler1.postDelayed(this,3000);
                if (apl.getStatus().equals("ONLINE")){
                    textView.setText("已连接");
                }else{
                    textView.setText("未连接");
                }
            }
        };
        handler1.post(runnable);
    }
}
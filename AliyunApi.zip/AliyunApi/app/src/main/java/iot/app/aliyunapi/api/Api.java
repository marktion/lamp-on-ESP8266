package iot.app.aliyunapi.api;

import java.util.List;
import java.util.Map;

import iot.app.aliyunapi.model.device.Device;
import iot.app.aliyunapi.model.message.Property;
import iot.app.aliyunapi.model.message.ResMsg;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface Api {
    //构建实例
    Retrofit retrofit=new Retrofit.Builder()
            .baseUrl("https://iot.cn-shanghai.aliyuncs.com")//https阿里云需要加密
            .addConverterFactory(GsonConverterFactory.create())
            .build();

    @POST("/")
    Call<ResMsg<Property>> openApi(@QueryMap Map<String,String> map);
    @POST("/")
    Call<ResMsg<List<Device>>> QueryDevice(@QueryMap Map<String,String> map);

    //构建实例
    Retrofit retrofit_wifiweb=new Retrofit.Builder()
            .baseUrl("https://192.168.4.1/")
            .addConverterFactory(GsonConverterFactory.create())
            .build();

}

package iot.app.aliyunapi.model.message;

public class Property<T> {
    T List;
    T PropertyStatusInfo;

    public T getList() {
        return List;
    }
    public T getPropertyStatusInfo() {
        return PropertyStatusInfo;
    }
}
